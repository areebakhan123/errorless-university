# Tech Karo June 22 -- Mockup
